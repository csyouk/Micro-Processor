void Save_Img_To_Nand(void);
void Disable_Capture(void);
void Show_Saved_Img(void);
void Enable_Capture(void);
